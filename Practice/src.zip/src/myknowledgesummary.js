import React from 'react';
import ReactDOM from 'react-dom';

class MKS extends React.Component {
  render() {
    return <h2>Hi, I have learnt HTML5, CSS, JS, Servlets and Ajax!</h2>;
  }
}
export default MKS;
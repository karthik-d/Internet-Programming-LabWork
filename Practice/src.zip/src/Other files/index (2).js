//index.js
import React from 'react';
import ReactDOM from 'react-dom';

//const myfirstelement = <h1>Hello React!</h1>
<script>

class Car {
  constructor(name) {
    this.brand = name;
  }
}
car = new Car("Ford");
</script>
document.write(this.brand);


ReactDOM.render(this.brand, document.getElementById('root'));
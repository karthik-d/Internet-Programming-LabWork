import React, {Component} from 'react'

class WelcomeComponent extends Component
{
render()
{
return(<h1>Welcome Valli from the class component</h1>)
}
}
export default WelcomeComponent;	
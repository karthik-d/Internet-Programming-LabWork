import React from 'react'
  
const Search = () => {
  return (
    <div className='Search'>
      <h2>You are inside the Search Component</h2>
      <h4>URL: localhost:3000/courses/search</h4>
    </div>
  )
}
  
export default Search
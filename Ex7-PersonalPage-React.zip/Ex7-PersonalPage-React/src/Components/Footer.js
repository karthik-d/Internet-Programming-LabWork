import react from 'react';

const Footer = () => {
    return (
        <footer className={"Footer__container"}>
            <p className={"Footer__text"}>
                Credits: Karthik D
            </p>
        </footer>
    );
}

export default Footer;
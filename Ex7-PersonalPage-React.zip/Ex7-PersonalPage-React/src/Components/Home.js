import React from 'react';

const Home = () => {
    return (
        <div id="Home__content">
            <a href="mailto:karthik@mailbox.in">
                <div id="Home__nameWrapper">
                    <p class="Home__namecontent">Karthik D</p>
                    <p class="Home__affil">SSN College of Engineering</p>
                    <p class="Home__contact">Click to reach out to me</p>
                </div>
            </a>
        </div>
    );
}

export default Home;